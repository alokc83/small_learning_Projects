//
//  main.m
//  scrollViewTest
//
//  Created by Katie on 3/5/13.
//  Copyright (c) 2013 Mapps Lab. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "scrollViewTestAppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([scrollViewTestAppDelegate class]));
    }
}
